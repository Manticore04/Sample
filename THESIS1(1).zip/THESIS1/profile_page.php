<!DOCTYPE html>
<html>
<head>
  <title>Welcome - Depression Care Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  
</head>
<body>

<div class="container">
	
	<h3>Depression Care Management</h3>

	<div class="col-sm-3" style=" padding:50px; ">
	
		<div id="photo"style= "width: 50%; height: auto; padding-top: 50%; margin-top:20px; background-image:url('Bakeneko.jpg'); background-repeat:no-repeat; background-size:100%;"></div>
		
		<h4>Username</h4>
		<button type="button" class="btn btn-info">Take Online Self-Assessment</button>
		
		<br>
		<br>
		
		<button type="button" class="btn btn-info">Log-out</button>
		
	</div>
	
	<div class="col-sm-9" >
	
		<ul class="nav nav-tabs">
			<li class="active"><a href="#">PROGRESS</a></li>
			<li><a href="#">THOUGHT DIARY</a></li>
			<li><a href="#">ACTIVITIES</a></li>
			<li><a href="#">FORUM</a></li>
		</ul>
	
	</div>
	
</div>
</body>

<script>
$(document).ready(function()
{
  $("#photo").css("border-radius", "50%");
});

</script>

</html>