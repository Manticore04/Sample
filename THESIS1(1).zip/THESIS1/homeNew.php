<!DOCTYPE html>
<html>
<head>
  <title>HOME - Depression Care Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <style>
</head>

<title>Depression Care Management</title>

<body>

<nav class="navbar navbar-inverse navbar-fixed-top" id="nav" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Depression Care Management</a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li><a href="#section1">What is Depression</a></li>
          <li><a href="#section2">Symptoms</a></li>
		  
             <li><a href="#section3">How Can We Help</a></li>
            
            <li><a href="#section41">Depression Self-Assessment</a></li>
			
			<li><a href="#" data-toggle="modal" data-target="#loginModal">Login/Sign-up</a>
			
				
			</li>
			
		
          
          </li>
        </ul>
      </div>
    </div>
  </div>
</nav>  

				<!-- Modal -->
				<div id="loginModal" class="modal fade" role="dialog">
				<div class="modal-dialog">
				
				<!-- Modal content-->
				<div class="modal-content">
				<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">LOG-IN</h4>
				</div>
				<div class="modal-body">
				
				<input type="text"  placeholder="Username"> 
				<input type="password"  placeholder="Password">
				<button class="btn btn-info btn-sm">LOG-IN</button>
				<br>
					<h4>Not a member yet? SIGN UP</h4>	
					
				<input type="text"  placeholder="Username"> <br>
				<input type="text"  placeholder="Email"> <br>
				<input type="password"  placeholder="Password"> <br>
				<input type="password"  placeholder="Re-type Password"> <br>
					
				<button class="btn btn-info btn-sm">Count me in!</button>
				</div>
				<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>

		</div>
	</div>
	


</body>

</html>  
  