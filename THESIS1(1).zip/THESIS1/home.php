<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8"> 
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
	
	<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js'></script>
	<link rel="stylesheet" type="text/css" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css">
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>	

	<style>
		.arrow-down-beige {
		width: 0; 
		height: 0; 
		border-left: 35px solid transparent;
		border-right: 35px solid transparent;
		
		border-top: 30px solid #f7f0dd;
		}
		.arrow-down-green {
		width: 0; 
		height: 0; 
		border-left: 35px solid transparent;
		border-right: 35px solid transparent;
		
		border-top: 30px solid #b1ccb9;
		}
		
		.font-ubuntu{
			
			font-family:"Ubuntu";
			font-size:24px;
			color:#ffffff;
		}
	</style>
	
  </head>
  
  <title>HOME - Depression Care Management</title>
  
  <body>

		<div class="font-ubuntu" style="background-color:#22acb6; height:80px;">
		<div class="col-sm-4"><br>
			DEPRESSION CARE MANAGEMENT
		</div>
		<div class="col-sm-8"> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp TEST THOUGHT DIARY ACTIVITIES  
			<img src="home.png" height="80px" width="80px" alt="login" style="margin-top:0; "/>
			<img src="info.png" height="80px" width="80px" alt="login" style="margin-top:0;"/>
			
			<img src="login.png" height="80px" width="80px" alt="login" style="margin-top:0;"  />
				
				<!-- Trigger the modal with a button -->
		<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>
			<!-- Modal -->
				<div id="myModal" class="modal fade" role="dialog">
				<div class="modal-dialog">
				
				<!-- Modal content-->
				<div class="modal-content">
				<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">LOG-in</h4>
				</div>
				<div class="modal-body">
				<p>Some text in the modal.adsakjdhaskdjahsdkdsahkfhsdfdksjfhsdkj</p>
				<input type="text">
				</div>
				<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
				</div>

				</div>
				</div>
	
			
		</div>
		</div> 
		 
		<div style="background-color:#f7f0dd; height:550px; "> 
			
			<div class="col-sm-4" style=" height:500px;">
				<img src="depressed.png" style="margin:20px;" />
			</div>
			
			<div class="col-sm-8" style=" height:500px;">
				<h2 style="margin-top:20px;">Are you Depressed?</h2>
				<p>Depression, or Major Depressive Disorder (MDD) is a medical illness that affects how you feel, think and behave causing persistent feelings of sadness and loss of interest in previously enjoyed activities. Unlike sadness, Depression lasts for longer period that can lead to physical illness or worse - suicide.</p>
			
			</div>
			
		</div>
		
		<div style="background-color:#eb4d5c; height:700px; ">
			<center><div class="arrow-down-beige"></div></center> 
			<h2 style="margin-top:20px;">What are the symptoms?</h2>
			<p>If you don't have any medical condition, mood-incogruent delusions or hallucinations, yet five or more of the following symptoms have been present during the same 2 week period, you are positively experiencing a Major Depressive Episode* 
			Depressed mood
			Merkedly diminished interest or pleasure in all or almost all activities
			Significant weight loss or gain (greater thab 5% body weight), or increase or decrease in appetite
			Insomnia or hypersomnia
			Feeling more irritable than usual
			Fatigue or loss of energy
			Feeling of worthlessness or inappropriate guilt
			Diminished concentration or indecisiveness
			Reccurent thoughts of death or suicide
			*based on DSM-5 (Diagnostic and Statistical Manual of Mental Disorders, 5th Edition) Criteria for Major Depressive Episode
			</p>
		</div>
		
		<div style="background-color:#b1ccb9; height:500px; ">
			<div>How Can We Help?</div>
			 <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo">How can we help?</button>
			<div id="demo" class="collapse" style="background-color:pink; height:300px;">
				<h3>Depression Self-Assessment</h3>
				<h3>Thought Diary</h3>
				<h3>Information</h3>
				<h3>Safety Plan</h3>
			</div>
		</div>
		
		<div style="background-color:#23acb4; height:300px; ">
			<center><div class="arrow-down-green"></div></center>
		</div>
  
  </body>