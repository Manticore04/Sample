<!DOCTYPE html>
<html>
<head>
  <title>What is Depression? - Depression Care Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  
  <style>
  
  body {
      position: relative; 
  }
  #section1 {padding-top:50px;height:655px;color: #fff; background-color:pink;}
  #section2 {padding-top:0px;height:550px;color: black; background-color: #ffffff;}
  #section3 {padding-top:0px;height:800px;color: #fff; background-color: #8375b6;}
  #section4 {padding-top:50px;height:500px;color: black; background-color: #ffffff;}
  #section5 {padding-top:50px;height:100px;color: #fff; background-color: #3f3369;}

  
  </style>
  
</head>

<body style="background-color:lavender;">

<body>

<body data-spy="scroll" data-target=".navbar" data-offset="50">

<nav class="navbar navbar-inverse navbar-fixed-top" id="nav" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Depression Care Management</a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li><a href="#section1">What is Depression</a></li>
          <li><a href="#section2">Symptoms</a></li>
		  
             <li><a href="#section3">How Can We Help</a></li>
            
            <li><a href="#section5">Depression Self-Assessment</a></li>
		
			<li><a href="#" data-toggle="modal" data-target="#loginModal" >Log-in</a>
			<?php } ?>
	
			</li>

          
   
        </ul>
      </div>
    </div>
  </div>
</nav>  


<div id="section1" class="container-fluid">

<h1 style="text-align:center; margin-top:80px;">What is Depression?</h1>
	<p style="text-align:center; margin-top:50px; font-size:16px;">Depression, or Major Depressive Disorder (MDD) is a medical illness <br> that affects how you feel, think and behave causing persistent feelings <br> of sadness and loss of interest in previously enjoyed activities. Unlike sadness,<br> Depression lasts for longer period that can lead to physical illness or worse - suicide.
	
	</p>
	
	<p style="border-style:solid;
	padding:20px; text-decoration: none; color:#ffffff;">Learn More About Depression</p>
	
	

</div>

<div id="section2" class="container-fluid">
,fd.gs.fdg
</div>


</body>  
  
 </html> 