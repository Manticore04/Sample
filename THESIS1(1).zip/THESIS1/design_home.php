<!DOCTYPE html>
<html>
<head>
  <title>HOME - Depression Care Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
 <!--   <link rel="stylesheet" href="assets/css/bootstrap.min.css">
   <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css">
  <script src="assets/js/bootstrap.min.js"></script>
   <script src="assets/js/bootstrap.js"></script>
   <script src="assets/js/npm.js"></script>
   <script src="assets/js/jquery.js"></script> -->
<style>

body {
      position: relative; 
  }
  #section1 {padding-top:50px;height:655px;color: #fff; background-image: url(assets/img/header.jpg); background-repeat:no-repeat; background-size:100%;}
  #section2 {padding-top:0px;height:550px;color: black; background-color: #ffffff;}
  #section3 {padding-top:0px;height:800px;color: #fff; background-color: #8375b6;}
  #section4 {padding-top:50px;height:500px;color: black; background-color: #ffffff;}
  #section5 {padding-top:50px;height:100px;color: #fff; background-color: #3f3369;}

</style> 
</head>

<body>

<body data-spy="scroll" data-target=".navbar" data-offset="50">

<nav class="navbar navbar-inverse navbar-fixed-top" id="nav" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Depression Care Management</a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li><a href="#section1">What is Depression</a></li>
          <li><a href="#section2">Symptoms</a></li>
		  
             <li><a href="#section3">How Can We Help</a></li>
            
            <li><a href="#section5">Depression Self-Assessment</a></li>
			
			<li><a href="#" data-toggle="modal" data-target="#loginModal">Login/Sign-up</a>
			
			
			
				
			</li>

          
   
        </ul>
      </div>
    </div>
  </div>
</nav>  

				<!-- Modal -->
				<div id="loginModal" class="modal fade" role="dialog">
				<div class="modal-dialog">
				
				<!-- Modal content-->
				<div class="modal-content">
				<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			
				</div>
				<div class="modal-body">
				
				<div class="form-group col-xs-6">
				
				<h4>Log-In</h4>	
				
				<input type="text" class="form-control" id="username" placeholder="Username">
				<br>
				<input type="password" class="form-control" id="password" placeholder="Password">
				<br>
				<button class="btn btn-info btn-sm">LOG-IN</button>
				
				</div>
				
				
				<div class="form-group col-xs-6" style="border-left:0.5px solid lightgrey;">
				
					<h4>Not a member yet? SIGN UP</h4>	
					
					<input type="text" class="form-control" id="username" placeholder="Username"> <br>
					<input type="text" class="form-control" id="username" placeholder="Email"><br>
					<input type="password" class="form-control" id="username" placeholder="Password"> <br>
					<input type="password" class="form-control" id="username" placeholder="Re-type Password"> <br>
					
					<button class="btn btn-info btn-sm">Join now!</button>
				</div>
				<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
				</div>

				</div>
				</div>
				</div>
			

<div id="section1" class="container-fluid"> 

	
<hr>

	<h1 style="text-align:center; margin-top:80px;">Are You Depressed?</h1>
	<p style="text-align:center; margin-top:50px; font-size:16px;">Depression, or Major Depressive Disorder (MDD) is a medical illness <br> that affects how you feel, think and behave causing persistent feelings <br> of sadness and loss of interest in previously enjoyed activities. Unlike sadness,<br> Depression lasts for longer period that can lead to physical illness or worse - suicide.
	<br>
	<br>
	<br>
	<br>
	<a href="#" style="border-style:solid;
	padding:20px; text-decoration: none; color:#ffffff;">Learn More About Depression</a>
	</p>
</div>

<div id="section2" class="container-fluid">

	<h1 style="text-align:center; margin-top:80px;">What are the symptoms?</h1>
	<p style="text-align:center; margin-top:50px; font-size:16px;">
	If you don't have any medical condition, mood-incogruent delusions or hallucinations, yet five or more of the following symptoms have <br>
	been present during the same 2 week period, you are positively experiencing a Major Depressive Episode*
	</p>

	<div class="container">
	<div class="col-sm-6" style="background-color:none; position:relative;">
	<ul>
		<li>Depressed mood </li>
		<li>Markedly diminished interest or pleasure in all or almost all activities</li>
		<li>Significant weight loss or gain (greater thab 5% body weight), or increase or decrease in appetite</li>
		<li>Insomnia or hypersomnia</li>
	</ul>

	</div>
	<div class="col-sm-6" style="background-color:none; position:relative;">
	<ul>
		<li>Feeling more irritable than usual</li>
		<li>Fatigue or loss of energy</li>
		<li>Feeling of worthlessness or inappropriate guilt</li>
		<li>Diminished concentration or indecisiveness</li>
		<li>Reccurent thoughts of death or suicide</li> 
	</ul>
	</div>
	
	<div class="col-sm-12">
		<br>
		<i style="font-size:11px;">*based on DSM-5 (Diagnostic and Statistical Manual of Mental Disorders, 5th Edition) Criteria for Major Depressive Episode
		</i>
	</div>
	
	</div>

	
</div>

<div id="section3" class="container-fluid">
	<h1 style="text-align:center; margin-top:80px;">How We Can Help</h1>
	
	<div class="container">
	<div class="col-sm-6" style="text-align:center; margin-top:50px; position:relative;">
	<img src="assets/img/assessment.png" style="background-color:none; width:100px; height:100px; float:center;" />
	<h3>Depression Self-Assessment</h3>
	<p> Not sure if you need professional help? Take our Depression Self-Assessment to guide you and help you reach out.</p>
	<br>
	<img src="assets/img/diary.png" style="background-color:none; width:100px; height:100px; float:center;" />
	<h3>Thought Diary</h3>
	<p>Record situations you find distressing and challenge your thought into looking at the positive light.</p>
	
	</div>
	
	<div class="col-sm-6" style="text-align:center; margin-top:50px; position:relative;">
	
	<img src="assets/img/forum.png" style="width:100px; height:100px; float:center;" />
	<h3>Forums</h3>
	<p>Help one another and reach out with our forums.</p>
	<br>
	<br>
	<img src="assets/img/video.png" style=" width:100px; height:100px; float:center;" />
	<h3>Inspirational Videos</h3>
	<p>Watch inspirational videos of how people overcome depression.</p>		
	
	</div>
	</div>
		
</div>

<div id="section4" class="container-fluid" style="text-align:center;">
	<h1 style="margin-top:80px;">Take our Depression Self-Assessment</h1>
	
	<p>Based on above information, do you think you experience symptoms of Depression? <br>
	Answer our Depression Self-assessment to get help and assisstance.</p>
	<br>
	<br>
	<br>
	<br>
	
	<a href="#" style="border-style:solid;
	padding:20px; text-decoration: none; color:#ffffff; background-color:#8375b6;" >Take Depression Self-Assessment</a>
	
</div>	

<div id="section5" class="container-fluid" style="text-align:center;">

<div>

<script>
    $("#nav ul li a[href^='#']").on('click', function(e) {

       // prevent default anchor click behavior
       e.preventDefault();

       // animate
       $('html, body').animate({
           scrollTop: $(this.hash).offset().top
         }, 700, function(){
   
           // when done, add hash to url
           // (default click behaviour)
           window.location.hash = this.hash;
         });

    });
</script>

</body>


</html>