<!DOCTYPE html>
<html>
<head>
  <title>SELF-ASSESSMENT - Depression Care Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  
</head>

<body style="background-color:#8375b6;">

	<div class="container">
		
		<div class="col-sm-12" style="background-color:#fff; margin:0 auto; margin-top:100px; padding:20px;"> 
		1.)	Question number 1
		</div>
		<div class="col-sm-12" style="background-color:#fff; margin:0 auto; margin-top:20px; padding:20px;"> 
		A. Answer
		</div>
		<div class="col-sm-12" style="background-color:#fff; margin:0 auto; margin-top:20px; padding:20px;"> 
		B. Answer
		</div>
		<div class="col-sm-12" style="background-color:#fff; margin:0 auto; margin-top:20px; padding:20px;"> 
		C. Answer
		</div>
		<div class="col-sm-12" style="background-color:#fff; margin:0 auto; margin-top:20px; padding:20px;"> 
		D. Answer
		</div>
		
	</div>
	
	<div class="container">
	<div class="col-sm-8" style="margin-top:60px; padding:20px;">
		<div class="progress" style="border:0px solid; border-radius:25px; height:7px;">
			<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width:80%">
			</div>
		</div>
	</div>
	<div class="col-sm-4" style="margin-top:50px;">
		<ul class="pagination" style="float:right;">
			<li><a href="#">Previous</a></li>
			<li><a href="#">Next</a></li>
		</ul>
	</div>
	</div>

</body>

</html>