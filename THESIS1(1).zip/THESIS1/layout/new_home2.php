<!DOCTYPE html>
<html>

  <head>
 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
  <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/css/main.css">
  <script src="../assets/css/mainJS.js"></script>
  <script src="../assets/css/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
  <script src="../assets/css/jquery.min.js"></script>

  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

  <style type="text/css">

    .green .active a,
    .green .active a:hover {
      background-color: #5dc2a8;
    }


   body {
      position: relative; 
    }
    #section1 {padding-top:50px;height:500px;color: #56341e; background-color: #5dc2a8;}
    #section2 {padding-top:50px;height:500px;color: #56341e; background-color: #ffffff;}
    #section3 {padding-top:50px;height:500px;color: #56341e; background-color: #ebf6f5;}
    #section4 {padding-top:50px;height:500px;color: #56341e; background-color: #fbf4f0;}
    #section5 {padding-top:50px;height:500px;color: #56341e; background-color: #ffffff;}
    #section6 {padding-top:50px;height:500px;color: #56341e; background-color: #ebf6f5;}
  </style>

  </head>



<body data-spy="scroll" data-target=".navbar" data-offset="50">

<!--NAVBAR-->
<nav class="navbar navbar-inverse navbar-fixed-top" style="background-color: #e7f5f1;">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav nav-pills navbar-nav green">
          <li><a href="#section2">What is depression</a></li>
          <li><a href="#section3">Demographics and Risks</a></li>
          <li><a href="#section4">Symptoms</a></li>
          <li><a href="#section5">How can we help</a></li>
          <li><a href="#section6">Depression Assessment</a></li>
          <li><a href="#" data-toggle="modal" data-target="#modalLogin">Login</a></li>
          <li><a href="#">Signup</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav> 
<!--NAVBAR END-->   

<title>HOME</title>

<!-- Modal -->
<div id="modalLogin" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!--Are you depressed?-->   
<div id="section1" class="container-fluid" style="text-align: center;">
  <h1 style="color: #fff;">ARE YOU DEPRESSED?</h1>

  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#modalLogin">Open Modal</button>

  <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p>
  <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p>
</div>


<!--What is depression?-->   
<div id="section2" class="container-fluid">
  <center> <h1>WHAT IS DEPRESSION?</h1></center>
  <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p>
  <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p>
</div>

<!--Demographics and Risks-->   
<div id="section3" class="container-fluid">
  <h1>DEMOGRAPHICS</h1>
  <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p>
  <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p>
</div>

<!--Symptoms-->  
<div id="section4" class="container-fluid">
  <h1>Section 4 Submenu 1</h1>
  <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p>
  <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p>
</div>

<!--How can we help-->  
<div id="section5" class="container-fluid">
  <h1>Section 4 Submenu 2</h1>
  <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p>
  <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p>
</div>

<!--Assessment-->  
<div id="section6" class="container-fluid">
  <h1>Section 4 Submenu 2</h1>
  <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p>
  <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p>
</div>

</body>
</html>