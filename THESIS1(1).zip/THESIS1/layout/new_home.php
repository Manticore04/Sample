<!DOCTYPE html>
<html>
<head>
 
 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

  <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/css/main.css">
  <link href="../assets/css/scrolling-nav.css" rel="stylesheet">
  <script src="../assets/css/mainJS.js"></script>
  <script src="../assets/css/bootstrap.min.js"></script>
  <script src="../assets/js/jquery.easing.min.js"></script>
  <script src="../assets/js/scrolling-nav.js"></script>
  
  <link rel="stylesheet" type="text/css" href="../assets/css/style.css">

  <script src="../assets/css/jquery.min.js"></script>

  <style type="text/css">
    .navbar #nav > .active > li { color: red; }
  </style>>

  <body style="background-color: #5dc2a8;">

    <title>HOME</title>

    <body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color: #e7f5f1;">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top">DEPRESSION CARE</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav">
                    <!-- Hidden li included to remove active class from about link when scrolled up past about section -->
                    <li class="hidden">
                        <a class="page-scroll" href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#1">WHAT IS DEPRESSION</a>
                    </li>
                     <li>
                        <a class="page-scroll" href="#2">DEMOGRAPHICS AND RISKS</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#3">SYMPTOMS</a>
                    </li>
                     <li>
                        <a class="page-scroll" href="#4">HOW CAN WE HELP</a>
                    </li>
                     <li>
                        <a class="page-scroll" href="#5">DEPRESSION ASSESSMENT</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>


    <!-- WHAT IS DEPRESSION -->
    <section id="intro" class="1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Scrolling Nav</h1>
                    <p><strong>Usage Instructions:</strong> Make sure to include the <code>scrolling-nav.js</code>, <code>jquery.easing.min.js</code>, and <code>scrolling-nav.css</code> files. To make a link smooth scroll to another section on the page, give the link the <code>.page-scroll</code> class and set the link target to a corresponding ID on the page.</p>
                    <a class="btn btn-default page-scroll" href="#about">Click Me to Scroll Down!</a>
                </div>
            </div>
        </div>
    </section>

    <!-- DEMOGRAPHICS AND RISKS -->
    <section id="about" class="2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>About Section</h1>
                </div>
            </div>
        </div>
    </section>

    <!-- SYMPTOMS -->
    <section id="services" class="3">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Services Section</h1>
                </div>
            </div>
        </div>
    </section>

    <!-- HOW CAN WE HELP -->
    <section id="contact" class="4">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Contact Section</h1>
                </div>
            </div>
        </div>
    </section>

       <!-- DEPRESSION ASSESSMENT -->
    <section id="contact" class="4">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Contact Section</h1>
                </div>
            </div>
        </div>
    </section>

    <script>
      
       $(function() {
        $('#nav li a').click(function() {
           $('#nav li').removeClass();
           $($(this).attr('href')).addClass('active');
        });
     });

    </script>
  
    
  </body>


</html>