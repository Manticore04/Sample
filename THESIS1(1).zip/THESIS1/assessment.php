<!DOCTYPE html>
<html>
<head>
  <title>HOME - Depression Care Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <style>
  body {
      position: relative; 
  }
  #section1 {padding-top:50px;height:500px;color: #fff; background-color: #e66760;}
  #section2 {padding-top:0px;height:500px;color: #fff; background-color: #c4da87;}
  #section3 {padding-top:0px;height:500px;color: #fff; background-color: #fede87;}
  #section41 {padding-top:50px;height:500px;color: #fff; background-color: #e66760;}
  #section42 {padding-top:50px;height:100px;color: #fff; background-color: #c4da87;}
  
  	.arrow-down-beige {
		width: 0; 
		height: 0; 
		border-left: 35px solid transparent;
		border-right: 35px solid transparent;
		
		border-top: 30px solid #e66760;
		}
		.arrow-down-green {
		width: 0; 
		height: 0; 
		border-left: 35px solid transparent;
		border-right: 35px solid transparent;
		
		border-top: 30px solid #c4da87;
		}
  </style>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">

<nav class="navbar navbar-inverse navbar-fixed-top" id="nav" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Depression Care Management</a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li><a href="#section1">What is Depression</a></li>
          <li><a href="#section2">Symptoms</a></li>
		  
             <li><a href="#section3">How Can We Help</a></li>
            
            <li><a href="#section41">Depression Self-Assessment</a></li>
			
			<li><a href="#" data-toggle="modal" data-target="#loginModal">Login/Sign-up</a>
			
				
			</li>
			
		
          
          </li>
        </ul>
      </div>
    </div>
  </div>
</nav>  

				<!-- Modal -->
				<div id="loginModal" class="modal fade" role="dialog">
				<div class="modal-dialog">
				
				<!-- Modal content-->
				<div class="modal-content">
				<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">LOG-IN</h4>
				</div>
				<div class="modal-body">
				
				<input type="text"  placeholder="Username"> 
				<input type="password"  placeholder="Password">
				<button class="btn btn-info btn-sm">LOG-IN</button>
				<br>
					<h4>Not a member yet? SIGN UP</h4>	
					
					<input type="text"  placeholder="Username"> <br>
					<input type="text"  placeholder="Email"> <br>
					<input type="password"  placeholder="Password"> <br>
					<input type="password"  placeholder="Re-type Password"> <br>
					
					<button class="btn btn-info btn-sm">Count me in!</button>
					</div>
				<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
				</div>

				</div>
				</div>
			  

<div id="section1" class="container-fluid">
<h1> Depression Self-Assessment </h1>


</div>

</body>