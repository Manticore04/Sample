<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
class Home extends CI_Controller {

	public function index() 
	{

		$this->load->view('includes/head');
		$this->load->view('includes/navbar');
		$this->load->view('home');
		$this->load->view('includes/footer');
		
	}

	
	public function signup_form()
	{
		$this->load->view('includes/head');
		$this->load->view('includes/navbar');
		$this->load->view('signup');
		$this->load->view('includes/footer');
	}
	
	
	public function signup()
	{
	
		$this->load->model('user_model');
		$this->user_model->signup();
		echo "Success";
	}
	
		public function login() 
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		
		$this->load->model('user_model');
		$result = $this->user_model->login($username, $password);
		
		if($result)
		{
			redirect('user_controller/member');
		}
		else
		{
			$this->session->set_flashdata('message', 'Wrong Username or Password');
			redirect('/home');
		}
		
		
	}
	
	

}	