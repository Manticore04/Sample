<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
class Practice_login extends CI_Controller {

	public function index() 
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		
		$this->load->model('user_model');
		$result = $this->user_model->login2($username, $password);
		
		if($result)
		{
			redirect('user_controller/member');
		}
		else
		{
			echo "TAE";
		}
		
	}


	
}	