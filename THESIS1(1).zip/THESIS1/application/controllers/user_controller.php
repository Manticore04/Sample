<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
class User_controller extends CI_Controller {
	
	public function member()
	{
		
		$this->load->view('includes/head'); 
	//	$this->load->view('includes/navbar');
		
		if($this->session->userdata('admin')==1 ){
			
			$this->load->view('user_admin'); 
			$this->is_logged_in();

		} else{ 
		
			$this->load->view('user'); 
			$this->is_logged_in();
		}

		
	}
	
	function is_logged_in()
	{	
	
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			
			echo 'bawal';
			die();
			
		}
	
	}
	
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('home');
		
	} 

	public function diary()
	{
		$data = array(
			'diary_entry' => $this->input->post('diary_entry') ,
			'feeling' => $this->input->post('feeling') ,
			'userId' => $this->session->userdata('userId')
			 );

		 $this->db->insert('thought_diary', $data);	
		 echo "Diary updated";
	}
}
	