<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
class Assessment extends CI_Controller {

	public function index() 
	{
		
		// var_dump($_GET);
		// $this->cart->destroy();


		$this->load->library('pagination');
		$this->load->library('table');
		
		$config['base_url'] = 'http://localhost/THESIS1/index.php/assessment/index';
		$config['total_rows'] = $this->db->get('depression_assessment')->num_rows();
		$config['per_page'] = 1;
		$config['num_links'] = 5;
		$config['display_pages'] = FALSE;
		
		$config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
     //   $config['first_tag_open'] = '<li>';
     //   $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'PREVIOUS';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';

        $config['next_link'] = '';
        $config['next_tag_open'] = '';
        $config['next_tag_close'] = '';

     //   $config['last_tag_open'] = '<li>';
     //   $config['last_tag_close'] = '</li>';
		$this->pagination->initialize($config);
		$data=array();

		
		$last_page=false;


		if($this->uri->segment(3)<=8 and null !==$this->uri->segment(3))
		{

			$data['current_url']=$config['base_url']."/".($this->uri->segment(3)+1);
			$data['page_ctr']=$this->uri->segment(3)+1;
		}
		else
		{
			$data['current_url']=$config['base_url'];
			$data['page_ctr']=10;

			$last_page=true;
		}


		// var_dump($this->input->get('answer'));

		if($this->input->get('answer')!=false)
			{
				// var_dump($this->input->get('answer'));
				$found=false;
				$rowid=0;

				$this->db->where('rec_id',$this->input->get('answer'));
				$query=$this->db->get('multiple_answer');

				if($query->num_rows()>0)
				{
					$row = $query->row();
					$score=$row->score;

					foreach ($this->cart->contents() as  $items) 
					{
						if($items['id']==$data['page_ctr'] and $items['name']==$this->input->get('answer'))
						{
							$rowid=$items['rowid'];
							$found=true;
						}
					}

					if($found)
					{	
						// var_dump("natagpuan");

						$data = array('rowid' => $rowid,
						               'name'   => $this->input->get('answer'),
						               'price' =>$score
						            );

						$this->cart->update($data); 
					}
					else
					{
						// var_dump($score);
						$insert_data=array(  'id'      => $data['page_ctr']-1,
											 'qty'     => 1,
						                     'price'   => $score,
											 'name' =>$this->input->get('answer'));
						$this->cart->insert($insert_data);



					}
				}
			}

		if($last_page==false)
		{
			$data['pagination'] = $this->pagination->create_links();
			// var_dump($this->pagination->create_links());
			$query = $this->db->get('depression_assessment',$config['per_page'],	$this->uri->segment(3) );
			$data['records'] = $query->result_array();
		//	$data['answers'] = $query2->result_array();

			$query3 = $this->db->get_where('multiple_answer', array('question_id' => $data['records'][0]['questionId']));
			$data['answers'] = $query3->result_array();
			
		//	$data['records'] = $this->db->get('depression_assessment',	$config['per_page'],	$this->uri->segment(3) 	);   eto talaga yung gamit ko
			
			$this->load->view('includes/head');
			$this->load->view('includes/navbar');
			$this->load->view('test',$data);
			$this->load->view('includes/footer');
		}
		else
		{
			if($this->session->userdata('is_logged_in'))
			{

				$total = $this->cart->total() - 9;
				//
				if($total < 5 ) 
				{
					$data['id']=0;
				}
				elseif($total >= 5 and $total < 10)
				{
					$data['id']=1;
				}elseif ($total >= 10 and $total < 15) {
					$data['id']=2;
				}elseif ($total >= 15 and $total <  20) {
					$data['id']=3;
				}elseif ($total >20) {
					$data['id']=4;
				}

				$insert_data=array(  'date'      => date("Y-m-d H:m:s"),
									 'score'     => $total,
				                     'resultId'   => $data['id'],
									 'userId' =>$this->session->userdata('id'));

				$this->db->insert('user_result',$insert_data);

				$query_r = $this->db->get_where('depression_severity', array ('id' => $data['id']));
				$data['result'] = $query_r->result_array();
				// var_dump($this->cart->total());
				$this->load->view('includes/head');
				$this->load->view('includes/navbar');
				$this->load->view('result',$data);
				$this->load->view('includes/footer');
			}
			else
			{
				$total = $this->cart->total() - 9;
				//
				if($total < 5 ) 
				{
					$data['id']=0;
				}
				elseif($total >= 5 and $total < 10)
				{
					$data['id']=1;
				}elseif ($total >= 10 and $total < 15) {
					$data['id']=2;
				}elseif ($total >= 15 and $total <  20) {
					$data['id']=3;
				}elseif ($total >20) {
					$data['id']=4;
				}

				$query_r = $this->db->get_where('depression_severity', array ('id' => $data['id']));
				$data['result'] = $query_r->result_array();
				// var_dump($this->cart->total());
				$this->load->view('includes/head');
				$this->load->view('includes/navbar');
				$this->load->view('result',$data);
				$this->load->view('includes/footer');
			}			
		}

		// var_dump($this->cart->contents());
		
		// var_dump($this->cart->contents());
	}

	public function answer()
	{
		
	}

	public function result()
	{

		$this->load->view('includes/head');
		$this->load->view('includes/navbar');
		$this->load->view('result');
		$this->load->view('includes/footer');
		
	}
	
}	