<?php
	
class User_model extends CI_Model{
	
	function __construct()
	{
		parent::__construct();
	}
	
	public function signup () 
	{	
	
	$data = array(
		'username' => $this->input->post('username'),
		'email' => $this->input->post('email'),
		'password' => $this->input->post('password') 
	);
	
	return $this->db->insert('user', $data);	

	}
	

// DI ITO YUNG GINAGAMIT KO KANINA	
	function login ($username,$password)
	{

		$this->db->where('username',$username);
		$this->db->where('password',$password);
		$query = $this->db->get('user');
		
		if($query->num_rows()==1)
		{
		
			
			$row = $query->row();
			$data = array (
				'id'=>$row->userId,
				'username'=>$row->username,
				'email'=>$row->email,
				'icon'=>$row->icon,
				'admin' => $row->admin,
				'is_logged_in'=>true
			);
			
			$this->session->set_userdata($data);
			return true; 
			
		}
		else
		{
			return false;
		}
		
	}
	


}
?>