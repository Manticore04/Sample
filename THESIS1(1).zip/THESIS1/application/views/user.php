

<?php 
//Session
$username = ucfirst($this->session->userdata('username'));
$icon = $this->session->userdata('icon'); 
$email = $this->session->userdata('email');
$id = $this->session->userdata('userId');

?>	

<title>Welcome <?php echo $username;?>!</title>

<body>

<div class="container">
	
	<br>
	<br>
	<br>
	<br>
	<br>

	<div class="col-sm-3" style=" padding:50px; ">
	
		<div id="photo"style= "width: 100%; height: auto; padding-top: 100%; margin-top:20px; background-image:url('../../assets/profile_images/<?php echo $icon; ?>'); background-repeat:no-repeat; background-size:100%;"></div>
		
		<h4><?php echo $username; ?></h4>
		<a href="http://localhost/THESIS1/index.php/assessment/index/" type="button" style="text-decoration: none;">Take Online Self-Assessment</a>
		<br>
		<br>
		
		<a href="#" type="button" style="text-decoration: none;" >Edit Profile</a>
		<br>
		<br>
		
		
		<a href="<?php echo site_url('user_controller/logout'); ?>" class="btn btn-info" >Log-out</a>
		
	</div>
	
	<div class="col-sm-9" >
	
		<ul class="nav nav-tabs" style="background-color: #e9f6f4;">
			<li class="active"><a data-toggle="tab" href="#home">PROFILE</a></li>
			<li><a data-toggle="tab" href="#1">THOUGHT DIARY</a></li>
			<li><a data-toggle="tab" href="#2">ACTIVITIES</a></li>
			<li><a data-toggle="tab" href="#3">FORUM</a></li>
		</ul>
		
		<div class="tab-content">

		<!--Profile-->
		<div id="home" class="tab-pane fade in active">
		  <h3>WELCOME!</h3>
		  <br>
		  <h4>Current Assessment: </h4>
		  <h4>Recommendations: </h4>
		  <h4>Previous Results: </h4>
		  <?php $chart_result=array(); ?>

		</div>
		
		<!--Thought Diary-->
		<div id="1" class="tab-pane fade">
		  <h3>THOUGHT DIARY</h3>
		  <p>How's your day? <br> Input situations and how you feel about it.</p>

				<!--FORM-->
					<?php echo form_open('user_controller/diary');?>

					<div class="form-group">
					  <br>
					  <textarea class="form-control" rows="6" id="diary_entry" name="diary_entry" placeholder="Tell use what happened today"></textarea>
					  <br>	
					  <label>How do you feel about it?</label>
					  <select class="form-control" id="feeling" name="feeling">
						<option value="Sad"> Sad </option>
						<option value="Angry"> Angry </option>
						<option value="Happy"> Happy</option>
						<option value="Frustrated"> Frustrated</option>
					  </select>
					  <br>
		
					
      				  <?php echo form_submit('submit', 'Submit', 'class="btn btn-info btn-sm"' );?>
					  <?php echo form_close();?>
					  
					</div>
					
				<!--FORM-->
		</div>
		
		<!--Activities-->
		<div id="2" class="tab-pane fade">
		  <h3>ACTIVITIES</h3>
		  <p>Select an activity that can change your mood.</p>
		  <label>Recommended Acivities:</label>
					  <select class="form-control" id="sel1">
						<option>Practice Yoga for 30 minutes</option>
						<option>Gardening</option>
						<option>Care for a Pet</option>
						<option>Read a book</option>
						<option>Listen to music</option>
					  </select>
		</div>
		
		<!--Forum-->
		<div id="3" class="tab-pane fade">
		  <h3>FORUM</h3>
		  <p>Post a question or topic here.</p>
			<textarea class="form-control" rows="6" id="comment"></textarea>
			<br>
			<button class="btn btn-info">Submit</button>
			
			<!--Entries-->
			
				 <ul class="updatelist">
                	<li>
                    	<div class="updatethumb"><img src="images/thumbs/avatar1.png" alt="" /></div>
                        <div class="updatecontent">
                        	<div class="top">
                            	<a href="#" class="user">Agnes</a> - <a href="#">0 Comment</a> - 
                                <a href="#">Share</a> - <a href="#">Report</a> - <span>7 minutes ago</span>
                            </div><!--top-->
                            <div class="text">
                            	Unicorns, I love them. Unicorns, I love them. Uni uni unicorns, I love them. Uni unicorns, I could pet one if they were really real. And they are! So I bought one so I could pet it. Now it loves me, now I love it. La lala la la... 
                            </div><!--text-->
                        </div><!--updatecontent-->
                    </li>
                    
                    <li>
                    	<div class="updatethumb"><img src="images/thumbs/avatar2.png" alt="" /></div>
                        <div class="updatecontent">
                        	<div class="top">
                            	<a href="#" class="user">Vector</a> - <a href="#">2 Comments</a> - <a href="#">Share</a> - <a href="#">Report</a> - <span>1 hour ago</span>
                            </div><!--top-->
                            <div class="text">Some stuff... </div><!--text-->
                            <div class="photo">
                            	<a href="ajax/newsfeed/photo.html"><img src="images/preview/preview1.png" alt="" /></a>
                            </div><!--text-->
                        </div><!--updatecontent-->
                    </li>
                    
                    <li>
                    	<div class="updatethumb"><img src="images/thumbs/avatar3.png" alt="" /></div>
                        <div class="updatecontent">
                        	<div class="top">
                            	<a href="#" class="user">Fat Boy</a> - <a href="#">1 Comment</a> - <a href="#">Share</a> - <a href="#">Report</a> - <span>1 hour ago</span>
                            </div><!--top-->
                            <div class="text">These are Cheeto. </div><!--text-->
                            <div class="photo">
                            	<a href="ajax/newsfeed/photo2.html"><img src="images/preview/preview2.png" alt="" /></a>
                            </div><!--text-->
                        </div><!--updatecontent-->
                    </li>
                    
                	<li>
                    	<div class="updatethumb"><img src="images/thumbs/avatar4.png" alt="" /></div>
                        <div class="updatecontent">
                        	<div class="top">
                            	<a href="#" class="user">Agnes</a> - <a href="#">0 Comment</a> - 
                                <a href="#">Share</a> - <a href="#">Report</a> - <span>7 minutes ago</span>
                            </div><!--top-->
                            <div class="text">
                            	No one just *gets* as good as you do. *Especially* you. Start talking! Are you training with someone? 
                            </div><!--text-->
                        </div><!--updatecontent-->
                    </li>
                </ul>
			
			<!--Entries

		</div>
		</div>

		
	</div>
	
	
	
</div>
</body>

<script>
$(document).ready(function()
{
  $("#photo").css("border-radius", "50%");
});

</script>

</html> -->
<script>

function myFunction() {
    document.getElementById("page").innerHTML = "home";
	}

	alert('asdasdsa');
	var jArray= <?php echo json_encode($result);?>;
	

	new Morris.Line({

		
  // ID of the element in which to draw the chart.
	  element: 'myfirstchart',
	  // Chart data records -- each entry in this array corresponds to a point on
	  // the chart.
	  data: [
	    { year: '2008', value: 20 },
	    { year: '2009', value: 10 },
	    { year: '2010', value: 5 },
	    { year: '2011', value: 5 },
	    { year: '2012', value: 20 }
	  ],
	  // The name of the data record attribute that contains x-values.
	  xkey: 'year',
	  // A list of names of data record attributes that contain y-values.
	  ykeys: ['value'],
	  // Labels for the ykeys -- will be displayed when you hover over the
	  // chart.
	  labels: ['Value']
	});

</script>

<script src="<?php  echo base_url('layout/morris.js-0.5.1/raphael-min.js'); ?>"></script>
<script src="<?php  echo base_url('layout/morris.js-0.5.1/morris.min.js'); ?>"</script> 