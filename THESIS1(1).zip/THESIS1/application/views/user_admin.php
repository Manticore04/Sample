

<?php 
//Session
$username = ucfirst($this->session->userdata('username'));
$icon = $this->session->userdata('icon'); 
$email = $this->session->userdata('email');
$id = $this->session->userdata('userId');

?>	


<title>ADMIN <?php echo $username;?>!</title>

<body>

<div class="container">
	
	<br>
	<br>
	<br>
	<br>
	<br>

	<div class="col-sm-3" style=" padding:50px; ">
	
		<div id="photo"style= "width: 100%; height: auto; padding-top: 100%; margin-top:20px; background-image:url('../../assets/profile_images/<?php echo $icon; ?>'); background-repeat:no-repeat; background-size:100%;"></div>
		
		<h4><?php echo $username; ?></h4>
		<a href="http://localhost/THESIS1/index.php/assessment/index/" type="button" style="text-decoration: none;">Take Online Self-Assessment</a>
		<br>
		<br>
		
		<a href="#" type="button" style="text-decoration: none;" >Edit Profile</a>
		<br>
		<br>
		
		
		<a href="<?php echo site_url('user_controller/logout'); ?>" class="btn btn-info" >Log-out</a>
		
	</div>
	
	<div class="col-sm-9" >
	
		<ul class="nav nav-tabs" style="background-color: #e9f6f4;">
			<li class="active"><a data-toggle="tab" href="#home">PROFILE</a></li>
			<li><a data-toggle="tab" href="#1">LIST OF PATIENTS</a></li>
			<li><a data-toggle="tab" href="#2">ASSESSMENT</a></li>
			<li><a data-toggle="tab" href="#3">FORUM</a></li>
		</ul>
		
		<div class="tab-content">

		<!--Profile-->
		<div id="home" class="tab-pane fade in active">
		  <h3>WELCOME!</h3>
		  <hr>
		  <br>
		  <h4>Title: </h4>
		  <h4>Recommendations: </h4>
		  <h4>Previous Results: </h4>

		</div>
		
		<!--Thought Diary-->
		<div id="1" class="tab-pane fade">
		  <h3>LIST OF PATIENTS</h3>
		  <hr>
		  <p>How's your day? <br> Input situations and how you feel about it.</p>

				<!--FORM-->
					<?php echo form_open('user_controller/diary');?>

					<div class="form-group">
					  <br>
					  <textarea class="form-control" rows="6" id="diary_entry" name="diary_entry" placeholder="Tell use what happened today"></textarea>
					  <br>	
					  <label>How do you feel about it?</label>
					  <select class="form-control" id="feeling" name="feeling">
						<option value="Sad"> Sad </option>
						<option value="Angry"> Angry </option>
						<option value="Happy"> Happy</option>
						<option value="Frustrated"> Frustrated</option>
					  </select>
					  <br>
		
					
      				  <?php echo form_submit('submit', 'Submit', 'class="btn btn-info btn-sm"' );?>
					  <?php echo form_close();?>
					  
					</div>
					
				<!--FORM-->
		</div>
		
		<!--Activities-->
		<div id="2" class="tab-pane fade">
		  <h3>ACTIVITIES</h3>
		  <p>Select an activity that can change your mood.</p>
		  <label>Recommended Acivities:</label>
					  <select class="form-control" id="sel1">
						<option>Practice Yoga for 30 minutes</option>
						<option>Gardening</option>
						<option>Care for a Pet</option>
						<option>Read a book</option>
						<option>Listen to music</option>
					  </select>
		</div>
		
		<!--Forum-->
		<div id="3" class="tab-pane fade">
		  <h3>FORUM</h3>
		  <p>Post a question or topic here.</p>
		  <hr>
			<textarea class="form-control" rows="6" id="comment"></textarea>
			<br>
			<button class="btn btn-info">Submit</button>
			<hr>
			<div class="col-sm-5"><h4>Recent topics:</h4></div> <div class="col-sm-4"><input type="text" class="form-control" id="lname" placeholder="Search Topic" name="Lname"></div><div class="col-sm-2"> <button class="btn btn-info btn-sm">Search</button></div>
		</div>	