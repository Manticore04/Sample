
  
  <title>SELF-ASSESSMENT - Depression Care Management</title>

<body style="background-color:#5dc2a9;">
			
		
<div class="container">

<h4 style="margin-top:85px;">Over the <strong>last 2 weeks</strong>, how often have you been bothered by any of the following:</h4>
<hr>

<?php foreach($records as $question_item) {?>
		
	 <form method="get" action="<?php echo $current_url;?>">
     <?php// echo form_open('assessment/answer');?>
		

		<div class="col-sm-12" style="background-color:#fff; margin:0 auto; margin-top:20px; padding:20px; font-size: 24px; color: #56341e;"> 
		<?php echo $question_item['questionId'];?>.)
		<?php echo $question_item['questionItem'];?>
		</div>
		
		<?php foreach($answers as $answer){ ?>
		<div class="col-sm-12 myBox" style=" margin:0 auto; margin-top:20px; padding:5px; font-size: 20px; color: #56341e; text-align: center;"> 
			
			 <button class="btn" style="width: 1050px; height: 50px; font-size: 20px; background-color: #e9f6f4;" type="submit" name="answer" 
			 value="<?php echo $answer['rec_id'];?>">	
			 <?php

			 echo $answer['option_description'];
			
			 ?>
			 </button>

		</div>
		<?php } ?>
	 </form>

    <?php// echo form_close();?>	
		
		
<div class="container">
	<div class="col-sm-8" style="margin-top:60px; padding:20px;">
		<div class="progress" style="border:0px solid; border-radius:25px; height:7px;">
		<?php $percent = $question_item['questionId']* 6.67;

			$percent=($page_ctr/9)*100;
			 ?>
		
			<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="<?php echo $percent; ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $percent; ?>%">
			</div>
		</div>
	</div>
	<div class="col-sm-4" style="margin-top:50px;">
		<div style="float:right;">
			<?php  echo $pagination; 
			// var_dump($next);
			// var_dump($_GET);
			//	echo var_dump($pagination);?>
		</div>
	</div>
</div>

		
	
		
<?php }?>
		
</div>

<script>

	function myFunction() {
    document.getElementById("page").innerHTML = "NEXT";
	}

</script>
	


				
				