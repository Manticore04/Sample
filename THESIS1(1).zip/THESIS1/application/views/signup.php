
<?php echo br(5);?>
				
				<div class="form-group col-xs-6" >
				
				<?php echo form_open('home/signup');?>
					<h4>SIGN UP</h4>	
					
					<input type="text" class="form-control" name="username" id="username" placeholder="Username" value="<?php echo set_value('username');?>"> <br>
					<input type="text" class="form-control" name="email" id="email" placeholder="Email" value="<?php echo set_value('email');?>"><br>
					<input type="password" class="form-control" name="password" id="password" placeholder="Password" value="<?php echo set_value('password');?>"> <br>
					<input type="password" class="form-control" id="password2" placeholder="Re-type Password"> <br>
					
					 <?php echo form_submit('action','Join Now','class="btn btn-info btn-sm"');?> 
					 
				</div>
			
				<button type="button" class="btn btn-default"> Close</button>
			
			