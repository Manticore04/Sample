<div>
<h4>PRACTICE LANG!</h4>

<?php echo $this->pagination->create_links(); ?>
</div>