
<style>

body {
      position: relative; 
  }
  #section0 {padding-top:50px;height:655px;color: #fff; background-image: url(../assets/img/header.jpg); background-repeat:no-repeat; background-size:100%;}
  #section1 {padding-top:0px;height:800px;color: #56341e; background-color: #ffffff;}
  #section2 {padding-top:0px;height:550px;color: #56341e; background-color: #ebf6f5;}
  #section3 {padding-top:50px;height:600px;color: #56341e; background-color: #fbf4f0;}
  #section4 {padding-top:50px;height:500px;color: #fff; background-color: #5dc2a9;}

</style>
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="50">

<nav class="navbar navbar-inverse navbar-fixed-top" id="nav" role="navigation" style="background-color: #e9f6f4;">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="<?php echo site_url('home');?>">Depression Care Management</a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav" style="font-weight: bold;">
          <li><a href="#section1">What is Depression</a></li>
          <li><a href="#section2">Symptoms</a></li>
          <li><a href="#section3">How Can We Help</a></li>
          <li><a href="#section4">Depression Self-Assessment</a></li>
          <?php if ($this->session->userdata('username') == NULL){?>
          <li><a href="#" data-toggle="modal" data-target="#loginModal">Login/Sign-up</a></li>
          <?php } else {?>
          <li><a href="<?php echo site_url('user_controller/member');?>"><?php echo $this->session->userdata('username'); } ?></a></li>
         </ul>
      </div>
    </div>
  </div>
</nav>  

<!-- Modal -->
        <div id="loginModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
        
        <!-- Modal content-->
        <div class="modal-content">
        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      
        </div>
        <div class="modal-body">
        
        <div class="form-group col-xs-6">
        
        <h4>Log-In</h4> 
        <?php echo form_open('home/login');?>
        <input type="text" class="form-control" id="username" name="username" placeholder="Username">
        <br>
        <input type="password" class="form-control" id="password" name="password" placeholder="Password">
        <br>
        <?php if($this->session->flashdata('message')!= NULL){?>
        <div id="infoMessage" class="alert alert-danger"><?php echo $this->session->flashdata('message'); ?></div>
        <?php }?>
        <?php echo form_submit('submit', 'LOG-IN', 'class="btn btn-info btn-sm"' );?>
        <?php echo form_close();?>

        
        </div>
        
        
        <div class="form-group col-xs-6" style="border-left:0.5px solid lightgrey;">

      
        
          <h4>Not a member yet? SIGN UP</h4>  
        
          <?php echo form_open('home/signup');?>
          <input type="text" class="form-control" id="username" name="username" placeholder="Username"> <br>
          <input type="text" class="form-control" id="email" name="email" placeholder="Email"><br>
          <input type="password" class="form-control" id="password" name="password" placeholder="Password"> <br>
          <input type="password" class="form-control"  placeholder="Re-type Password"> <br>
          <?php echo form_submit('join', 'Join', 'class="btn btn-info btn-sm"' );?>
            <?php echo form_close();?>
       
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </div>

        </div>
        </div>
        </div>

        <script type="text/javascript">
         /** var url = window.location.href;
          if(url.indexOf('?error=') != -1 || url.IndexOf('/?error=') != -1) {
          $('#MyModal').modal('show');
          } **/
          var $error = $this->session->flashdata('message');
          if($error!=NULL){
             $('#loginModal').modal('show');  
          }
        </script>
