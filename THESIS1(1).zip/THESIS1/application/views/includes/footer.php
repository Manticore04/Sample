
<br>
<div class="col-sm-12">
<footer id="footer" class="container-fluid footer" style="text-align:center; background-color:lavander;">

Footer &copy 2015
</footer>
</div>


</body>

</html>