
  <title>HOME - Depression Care Management</title>
	

<div id="section0" class="container-fluid"> 


<!--Are you depressed?-->
	<h1 style="text-align:center; margin-top:80px;">Are You Depressed?</h1>
	<p style="text-align:center; margin-top:50px; font-size:20px;">Depression, or Major Depressive Disorder (MDD) is a medical illness <br> that affects how you feel, think and behave causing persistent feelings <br> of sadness and loss of interest in previously enjoyed activities. Unlike sadness,<br> Depression lasts for longer period that can lead to physical illness or worse - suicide.
	<br>
	<br>
	<br>
	<br>
	<a href="#section1" style="border-style:solid;
	padding:20px; text-decoration: none; color:#ffffff;">Learn More About Depression</a>
	</p>
</div>


<!--What is depression?-->
<div id="section1" class="container-fluid">

<div class="container">
	<h1 style="text-align:center; margin-top:80px;">What is Depression?</h1>
	<p style="text-align:block; margin-top:50px; font-size:16px;">
	Depression is a serious medical condition that needs proper care and attention. It can happen to anyone -  and does happen to one in ten of us over our lifetimes. Different factors that make it more likely to happen include biological make-up, upbringing, or reaction to life events. What keeps it going though, is how we deal with those things. The way we think and what we do affects the way we feel. Depression is often accompanied by other feelings such as guilt, shame, anger and anxiety.
	<br>
	<br>
	<h3>Thoughts</h3>
	<br>
	
	People who are depressed tend to think very negatively about themselves, the future and the world around them. It can be like seeing life through “gloomy specs”. <br>
	We can dwell on these thoughts repeatedly, mulling over things, asking ourselves why, thinking regretful things about the past, what we should or shouldn't have done.
	<br>
	<br>
	<h3>Behaviours</h3>
	<br>
	
	Because of the tiredness, difficulty sleeping and eating, and negative style of thinking, we tend to do less and less. We stop doing the things we used to do and enjoy. It could get so bad that we can't even go to work, or do things at home. We want to stay in bed, or stay at home doing very little. We might isolate ourselves from friends and family.

	</p>

	<div class="container">
	<div class="col-sm-6" style="background-color:none; position:relative; margin-top:20px;">
	<h3>Demographics</h3>	
	<ul>
		<li>Women are 2x more likely to develop depression. </li>
		<li>About 1 in 10 people will experience depression
		during their lifetime.</li>
		<li>Most people experience their first depressive
		episode between ages 20 and 30.</li>
	</ul>

	</div>
	<div class="col-sm-6" style="background-color:none; position:relative;  margin-top:20px;">
	<h3>Risks for Depression</h3>
	<ul>
		<li>Family history of depression or similar disorders.</li>
		<li>Poverty, unemployment, social isolation, and other
		stressful life events.</li>
		<li>Regular drug and alcohol use.</li> 
	</ul>
	</div>
	
	
	</div>
	</div>
	
</div>


<!--Symptoms-->
<div id="section2" class="container-fluid">

	<h1 style="text-align:center; margin-top:80px;">What are the symptoms?</h1>
	<p style="text-align:center; margin-top:50px; font-size:16px;">
	If you don't have any medical condition, mood-incogruent delusions or hallucinations, yet five or more of the following symptoms have <br>
	been present during the same 2 week period, you are positively experiencing a Major Depressive Episode*
	</p>

	<div class="container">
	<div class="col-sm-6" style="background-color:none; position:relative; margin-top:20px;">
	<ul>
		<li>Depressed mood </li>
		<li>Markedly diminished interest or pleasure in all or almost all activities</li>
		<li>Significant weight loss or gain (greater thab 5% body weight), or increase or decrease in appetite</li>
		<li>Insomnia or hypersomnia</li>
	</ul>

	</div>
	<div class="col-sm-6" style="background-color:none; position:relative;  margin-top:20px;">
	<ul>
		<li>Feeling more irritable than usual</li>
		<li>Fatigue or loss of energy</li>
		<li>Feeling of worthlessness or inappropriate guilt</li>
		<li>Diminished concentration or indecisiveness</li>
		<li>Reccurent thoughts of death or suicide</li> 
	</ul>
	</div>
	
	<div class="col-sm-12">
		<br>
		<i style="font-size:11px;">*based on DSM-5 (Diagnostic and Statistical Manual of Mental Disorders, 5th Edition) Criteria for Major Depressive Episode
		</i>
	</div>
	
	</div>

	
</div>

<!--How We Can Help-->
<div id="section3" class="container-fluid">
	<h1 style="text-align:center; margin-top:0px;">How We Can Help</h1>
	
	<div class="container">
	<div class="col-sm-6" style="text-align:center; margin-top:50px; position:relative;">
	<img src="../assets/img/assessment.png" style="background-color:none; width:100px; height:100px; float:center;" />
	<h3>Depression Self-Assessment</h3>
	<p> Not sure if you need professional help? Take our Depression Self-Assessment to guide you and help you reach out.</p>
	<br>
	<img src="../assets/img/diary.png" style="background-color:none; width:100px; height:100px; float:center;" />
	<h3>Thought Diary</h3>
	<p>Record situations you find distressing and challenge your thought into looking at the positive light.</p>
	
	</div>
	
	<div class="col-sm-6" style="text-align:center; margin-top:50px; position:relative;">
	
	<img src="../assets/img/forum.png" style="width:100px; height:100px; float:center;" />
	<h3>Forums</h3>
	<p>Help one another and reach out with our forums.</p>
	<br>
	<br>
	<img src="../assets/img/video.png" style=" width:100px; height:100px; float:center;" />
	<h3>Inspirational Videos</h3>
	<p>Watch inspirational videos of how people overcome depression.</p>		
	
	</div>
	</div>
		
</div>

<!--Assessment-->
<div id="section4" class="container-fluid" style="text-align:center;">
	<h1 style="margin-top:80px;">Take our Depression Self-Assessment</h1>
	
	<p>Based on above information, do you think you experience symptoms of Depression? <br>
	Answer our Depression Self-assessment to get help and assisstance.</p>
	<br>
	<br>
	<br>
	<br>
	<strong>
	<a href="http://localhost/THESIS1/index.php/assessment/index/" style="border-style:solid;
	padding:20px; text-decoration: none; color:#5dc2a9; background-color:#e9f6f4;" >Take Depression Self-Assessment</a>
	</strong>
</div>	



