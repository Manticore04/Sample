
  
  <title>SELF-ASSESSMENT - Depression Care Management</title>
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
<body style="background-color:#5dc2a9;">
			
		
<div class="container">

<h4 style="margin-top:85px;">Depression Assessment Result:</h4>
<hr>
		
		<!--If not a member yet-->
		<?php if ($this->session->userdata('is_logged_in')== FALSE){ ?>

		
	        <div class="form-group col-xs-4" style="background-color: #e9f6f4; padding: 15px; ">
	        <h4>Not a member yet? SIGN UP</h4> 
	        <p>We encourage you to create an account to monitor your mental health, talk to people who can answer your questions, and help inspire other people who might be suffering depression. </p> 
	        
	          <?php echo form_open('home/signup');?>
	          <input type="text" class="form-control" id="username" name="username" placeholder="Username"> <br>
	          <input type="text" class="form-control" id="email" name="email" placeholder="Email"><br>
	          <input type="password" class="form-control" id="password" name="password" placeholder="Password"> <br>
	          <input type="password" class="form-control"  placeholder="Re-type Password"> <br>
	          <?php echo form_submit('join', 'Join', 'class="btn btn-info btn-sm"' );?>
	            <?php echo form_close();?>
	       
	        </div>
	        
		<?php } ?>	

		<!--If not a member yet-->
		
		<div class="<?php if($this->session->userdata('is_logged_in')== FALSE){echo "col-sm-7";} else{echo "col-sm-12";} ?> " style="background-color:#fff; margin:0 auto; margin-top:20px; padding:15px; font-size: 24px; color: #56341e; <?php if($this->session->userdata('is_logged_in')== FALSE){echo "float:right; " ;} ?> ">
		RESULT HERE:
		
			
			<?php
			$chart_result=array();


			foreach($result as $r)
			{
				// array_push($chart, array("Date"=>$r['date'],))


				echo $r['severity'];
				echo "<br>";
				echo "RECOMENDATION: ";
				echo $r['action'];
				echo "<br>";
				echo $r['recommendation'];
			}

			?>

		</div>


		
		<div class="col-sm-12 myBox" style=" margin:0 auto; margin-top:20px; padding:5px; font-size: 20px; color: #56341e; text-align: center;"> 


		<div id="myfirstchart" style="height: 250px;"></div>
		

</div>
<?php 



?>
<script>
/*
	function myFunction() {
    document.getElementById("page").innerHTML = "NEXT";
	}

	alert('asdasdsa');
	var jArray= <?php echo json_encode($result);?>;
	

	new Morris.Line({

		
  // ID of the element in which to draw the chart.
	  element: 'myfirstchart',
	  // Chart data records -- each entry in this array corresponds to a point on
	  // the chart.
	  data: [
	    { year: '2008', value: 20 },
	    { year: '2009', value: 10 },
	    { year: '2010', value: 5 },
	    { year: '2011', value: 5 },
	    { year: '2012', value: 20 }
	  ],
	  // The name of the data record attribute that contains x-values.
	  xkey: 'year',
	  // A list of names of data record attributes that contain y-values.
	  ykeys: ['value'],
	  // Labels for the ykeys -- will be displayed when you hover over the
	  // chart.
	  labels: ['Value']
	});
*/

</script>
	


				
				